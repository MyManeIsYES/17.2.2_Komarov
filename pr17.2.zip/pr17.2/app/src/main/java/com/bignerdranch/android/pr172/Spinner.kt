package com.bignerdranch.android.pr172

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner

class spinner : AppCompatActivity() {
     lateinit var spinner: Spinner
     val numbers: Array<String> = arrayOf("das", "d","sdf")

     @Override
     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)

         spinner = findViewById(R.id.spinner1)


         ArrayAdapter.createFromResource(
             this,
             R.array.numbers,
             android.R.layout.simple_spinner_item,).also { adapter ->
             adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
             spinner.adapter = adapter
         }
     }
 }
